<?php

/**
 * The base MySQL settings of Osclass
 */
define('MULTISITE', 0);

/** MySQL database name for Osclass */
define('DB_NAME', 'test');

/** MySQL database username */
define('DB_USER', 'test');

/** MySQL database password */
define('DB_PASSWORD', 'test');

/** MySQL hostname */
define('DB_HOST', 'mysql');

/** Database Table prefix */
define('DB_TABLE_PREFIX', 'os_');

define('REL_WEB_URL', '/');

define('WEB_PATH', 'http://test.test/');

?>
